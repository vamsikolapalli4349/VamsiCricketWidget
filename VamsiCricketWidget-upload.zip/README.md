# Vamsi Cricket Widget

A tiny **2×1 Android cricket score widget** designed to feel like the compact ESPN/Cricinfo score card.

## What it does

- Exact target size: **2×1 home-screen cells** (`targetCellWidth=2`, `targetCellHeight=1`)
- Shows two team abbreviations + current score
- `● LIVE`, `UPCOMING`, or `FINAL` state
- Tap the small `↻` / status text to refresh immediately
- Preferred team setting (default: **India**)
- Optional **1-minute Live Mode** using a foreground service
- When the chosen match is not live yet, Live Mode backs off to a 5-minute refresh
- No API key required

## Data source

The app reads ESPN's public cricket scoreboard-header JSON endpoint:

`https://site.api.espn.com/apis/personalized/v2/scoreboard/header?sport=cricket&region=in&tz=Asia%2FCalcutta`

This endpoint is public but **not an officially supported ESPN developer API**. It can change without notice. The widget is for personal use and does not bundle ESPN branding or copyrighted artwork.

## Build in Android Studio

1. Install Android Studio.
2. Open this folder: `VamsiCricketWidget`.
3. Let Gradle sync.
4. Connect the Android phone with USB debugging, or use an emulator.
5. Click **Run**, or choose **Build → Build APK(s)**.
6. Debug APK appears under `app/build/outputs/apk/debug/app-debug.apk`.

Requirements used by this project:

- Android Gradle Plugin 8.7.3
- Gradle 8.9 (Android Studio can supply/download it)
- JDK 17
- compileSdk 35
- minSdk 26

## Put the widget on the phone

1. Install the APK.
2. Open **Cricket Score Widget** once.
3. Keep `India` or change the preferred team.
4. Tap **Save + refresh now**.
5. Long-press the phone home screen → **Widgets** → **Cricket Score Widget**.
6. Drag the **2×1** widget to the home screen.
7. Optional: open the app and tap **Start 1-minute live mode** during a match.

## Battery note

Android normally limits periodic widget refreshes. The widget therefore has two modes:

- normal widget refresh: Android's periodic refresh + manual `↻`
- Live Mode: foreground service with a persistent low-priority notification; 1 minute while live, 5 minutes while waiting

This is analogous to keeping a tiny scorer running only when you want a genuinely live scoreboard.

## GitHub one-click build

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Push the project to GitHub, run **Build Android APK**, and download the `VamsiCricketWidget-debug` artifact.
