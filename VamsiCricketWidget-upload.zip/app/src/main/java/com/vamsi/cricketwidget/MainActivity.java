package com.vamsi.cricketwidget;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText preferredTeam;
    private TextView previewLine1;
    private TextView previewLine2;
    private TextView previewSummary;
    private TextView stateText;
    private Button liveToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferredTeam = findViewById(R.id.preferredTeam);
        previewLine1 = findViewById(R.id.previewLine1);
        previewLine2 = findViewById(R.id.previewLine2);
        previewSummary = findViewById(R.id.previewSummary);
        stateText = findViewById(R.id.stateText);
        liveToggle = findViewById(R.id.liveToggle);
        Button saveRefresh = findViewById(R.id.saveRefresh);

        preferredTeam.setText(Prefs.getPreferredTeam(this));
        updateLiveButton();

        saveRefresh.setOnClickListener(v -> {
            savePreference();
            refreshPreview();
        });

        liveToggle.setOnClickListener(v -> {
            savePreference();
            if (Prefs.isLiveMode(this)) {
                Intent stop = new Intent(this, LiveScoreService.class);
                stop.setAction(LiveScoreService.ACTION_STOP);
                startService(stop);
                Prefs.setLiveMode(this, false);
                stateText.setText("Live mode stopped");
                updateLiveButton();
            } else {
                requestNotificationPermissionIfNeeded();
                Intent start = new Intent(this, LiveScoreService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
                else startService(start);
                Prefs.setLiveMode(this, true);
                stateText.setText("Live mode running");
                updateLiveButton();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateLiveButton();
    }

    private void savePreference() {
        Prefs.setPreferredTeam(this, preferredTeam.getText().toString());
    }

    private void refreshPreview() {
        stateText.setText("Fetching latest score…");
        executor.execute(() -> {
            MatchSnapshot snapshot;
            try {
                snapshot = new CricketRepository().fetchBestMatch(Prefs.getPreferredTeam(this));
                WidgetRenderer.render(this, snapshot);
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Refresh failed" : e.getMessage();
                snapshot = new MatchSnapshot("CRIC", "", "—", "—", "unknown", message, "", System.currentTimeMillis());
                WidgetRenderer.renderMessage(this, "Tap ↻ to retry");
            }
            MatchSnapshot finalSnapshot = snapshot;
            runOnUiThread(() -> showSnapshot(finalSnapshot));
        });
    }

    private void showSnapshot(MatchSnapshot s) {
        previewLine1.setText(s.team1 + "   " + s.score1 + "    " + s.statusLabel());
        previewLine2.setText(s.team2 + "   " + s.score2 + "    ↻");
        String extra = s.summary;
        if (extra == null || extra.isEmpty()) extra = s.detail;
        previewSummary.setText(extra == null || extra.isEmpty() ? "Latest score loaded" : extra);
        stateText.setText("Widget updated");
    }

    private void updateLiveButton() {
        if (liveToggle == null) return;
        liveToggle.setText(Prefs.isLiveMode(this)
                ? "Stop live mode"
                : "Start 1-minute live mode");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 90);
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
