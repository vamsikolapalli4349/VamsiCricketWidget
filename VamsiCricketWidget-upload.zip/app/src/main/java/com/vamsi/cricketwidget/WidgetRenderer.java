package com.vamsi.cricketwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;

public final class WidgetRenderer {
    private WidgetRenderer() {}

    public static void render(Context context, MatchSnapshot snapshot) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, CricketWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) {
            manager.updateAppWidget(id, buildViews(context, snapshot));
        }
    }

    public static void renderMessage(Context context, String message) {
        MatchSnapshot snapshot = new MatchSnapshot(
                "CRIC", "", "—", "—", "unknown", message, "", System.currentTimeMillis());
        render(context, snapshot);
    }

    private static RemoteViews buildViews(Context context, MatchSnapshot s) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_cricket);
        views.setTextViewText(R.id.team1, s.team1);
        views.setTextViewText(R.id.score1, trimScore(s.score1));
        views.setTextViewText(R.id.team2, s.team2);
        views.setTextViewText(R.id.score2, trimScore(s.score2));
        views.setTextViewText(R.id.status, s.statusLabel());
        views.setTextViewText(R.id.summary, "↻");

        int statusColor = s.isLive() ? Color.rgb(255, 77, 94) : Color.rgb(165, 171, 181);
        views.setTextColor(R.id.status, statusColor);

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                context, 20, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPi);

        Intent refresh = new Intent(context, CricketWidgetProvider.class);
        refresh.setAction(CricketWidgetProvider.ACTION_REFRESH);
        PendingIntent refreshPi = PendingIntent.getBroadcast(
                context, 21, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.summary, refreshPi);
        views.setOnClickPendingIntent(R.id.status, refreshPi);

        return views;
    }

    private static String trimScore(String score) {
        if (score == null || score.isEmpty()) return "—";
        if (score.length() <= 18) return score;
        return score.substring(0, 17) + "…";
    }
}
