package com.vamsi.cricketwidget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CricketWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "com.vamsi.cricketwidget.REFRESH";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        refreshAsync(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            final PendingResult pending = goAsync();
            EXECUTOR.execute(() -> {
                try {
                    refreshBlocking(context.getApplicationContext());
                } finally {
                    pending.finish();
                }
            });
        }
    }

    public static void refreshAsync(Context context) {
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> refreshBlocking(app));
    }

    public static MatchSnapshot refreshBlocking(Context context) {
        try {
            WidgetRenderer.renderMessage(context, "Refreshing…");
            MatchSnapshot snapshot = new CricketRepository()
                    .fetchBestMatch(Prefs.getPreferredTeam(context));
            WidgetRenderer.render(context, snapshot);
            return snapshot;
        } catch (Exception e) {
            WidgetRenderer.renderMessage(context, "Tap ↻ to retry");
            return new MatchSnapshot("CRIC", "", "—", "—", "unknown",
                    e.getMessage() == null ? "Refresh failed" : e.getMessage(), "", System.currentTimeMillis());
        }
    }
}
